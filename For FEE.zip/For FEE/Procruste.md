setwd('/Users/liyixian1990/Desktop/test2')
env<-read.csv('c4.csv',header=T,row.names=1)#要保留第一列

library(vegan)
env.dist<-vegdist(scale(env),'euclid')#一般环境距离用欧式距离，建议最好用hellinger
#epi.dist<-vegdist(scale(epi),'jaccard')#遗传距离就用默认的bray-crutis，这个看有没有更合适的, 这里改成了jaccard

epi.dist2<-read.csv('cGD.csv')
ep3<-dist(epi.dist2,diag = 1,upper=0)
ep3

epi.nmds <- monoMDS(ep3)#因为两个数据集属性不同，所要降维，他这里用nmds，但是小白鱼用pca,后面再贴一个小白鱼的代码
env.nmds <- monoMDS(env.dist)

procrust.test<-procrustes(env.nmds,epi.nmds,symmetric=T)#前边是目标矩阵，后边是控制矩阵,这里应该是前边代表环境，后边代表遗传，解释为遗传依赖环境，遗传匹配于环境
summary(procrust.test)

plot(procrust.test,kind=2)
residuals(procrust.test)

set.seed(100)
procrust.test.t<-protest(epi.nmds,env.nmds,permutations = 999)
procrust.test.t

procrust.test.t$

  procrust.test.t$signif

library(ggplot2)

Pro_Y <- cbind(data.frame(procrust.test.t$Yrot), data.frame(procrust.test.t$X))
Pro_X <- data.frame(procrust.test.t$rotation)

group<-read.csv('cgroup.csv',row.names=1)
Pro_Y2<-cbind(Pro_Y,group)

ggplot(data=Pro_Y2) +
  geom_segment(aes(x = X1, y = X2,
                   xend = (X1 + MDS1)/2, yend = (X2 + MDS2)/2),
               arrow = arrow(length = unit(0, 'cm')),
               color = "black", size = 1.2) +
  geom_segment(aes(x = (X1 + MDS1)/2, y = (X2 + MDS2)/2,
                   xend = MDS1, yend = MDS2),
               arrow = arrow(length = unit(0.4, 'cm')),
               color = "black", size = 1.2) +
  geom_point(aes(X1, X2,color=cluster), size = 6, shape = 16) +
  scale_color_manual(values = c('orangered4', 'cyan4'))+
  geom_point(aes(MDS1, MDS2,color=cluster), size = 6, shape = 16) +
  theme(panel.grid = element_blank(), 
        panel.background = element_rect(color = 'black',
                                        fill = 'transparent'),
        legend.key = element_rect(fill = 'transparent'),
        axis.ticks.length = unit(0.2,"lines"),
        axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"),
        axis.title.x=element_text(colour='black', size=14),
        axis.title.y=element_text(colour='black', size=14),
        axis.text=element_text(colour='black',size=12)) +
  labs(x = 'NMDS1', y = 'NMDS2', color = '') +
  labs(title="Correlation between Epi-genetic diversity and Environment") +
  geom_vline(xintercept = 0, color = 'gray', linetype = 2, size = 1) +
  geom_hline(yintercept = 0, color = 'gray', linetype = 2, size = 1) +
  geom_abline(intercept = 0, slope = Pro_X[1,2]/Pro_X[1,1], size = 0.5) +
  geom_abline(intercept = 0, slope = Pro_X[2,2]/Pro_X[2,1], size = 0.5) +
  annotate('text', label = 'Procrustes analysis:\n
                    M2 = 0.514, p-value = 0.005',#这个值在前边那一步提取中会有
           x = -0.5, y = 0.4, size = 4,hjust = 0) +
  theme(plot.title = element_text(size=14,colour = "black",
                                  hjust = 0.5,face = "bold"))+
  theme(rect = element_rect(size=1.5))
                          
dev.off()


library(export)#输出ppt
graph2ppt(file="cepienv.ppt", append=T, height=6, width=8)

dev.off()
rm(list=ls())