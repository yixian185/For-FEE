setwd('/Users/liyixian1990/Desktop/test2')
library(vegan)
library(rdacca.hp)
library(UpSetVP)
gen<-read.csv('cepi1.csv',row.names=1)
env<-read.csv('capcoa.csv',row.names=1)

mod <- rdacca.hp(gen,env,method = 'RDA', var.part = TRUE, type = 'adjR2', scale = FALSE)#这里环境数据必须精简到和遗传参数差不多的数量，不然出不来结果

upset_vp(mod, plot.hp = TRUE, order.part = 'effect', nVar = 40)
upset_vp(mod, plot.hp = TRUE, order.part = 'degree', nVar = 40)

barplot_hp(mod, col.fill = 'var', 
           col.color = c('#F39B7FFF', '#8491B4FF', '#91D1C2FF', '#DC0000FF'))#这里有4个响应变量,最后组合的时候在PDF里编辑时，把颜色条复制过来就行

dev.off()

最后组合图中，镜像转换就行，别选漏了