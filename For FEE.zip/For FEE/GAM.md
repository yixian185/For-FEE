setwd('/Users/liyixian1990/Desktop/test4') 
set.seed(100)
library(vegan)

env<-read.csv('c4.csv',row.names=1)
#h.env<-decostand(env, method='hellinger')#这里就不用这个转换了

epi.dist2<-read.csv('cGD.csv')#这里用popgene那个距离，对角线那个
ep3<-dist(epi.dist2,diag = 1,upper=0)#1代表对角线是coerce相关，0代表去掉上边

vare.mds <- monoMDS(ep3, distance='jaccard',k=2)#杰卡德距离
vare.mds#要stress值

fit<-ordisurf(vare.mds ~ MTCoQ, env, bubble = 5)#要先运行一下，不然下一步出不来图
fit1<-ordisurf(vare.mds ~ MTCoQ, env, col = "blue", add = TRUE,
               select = FALSE, method = "GCV.Cp")
summary(fit1)#要deviance explained值和p值


library(ggplot2)

library(metR)
library(ggrepel)

group <- read.csv('cgroup.csv',row.names=1)

ordi.grid <- fit1$grid

ordi.mite <- expand.grid(x = ordi.grid$x, y = ordi.grid$y)
ordi.mite$z <- as.vector(ordi.grid$z)
ordi.mite.na <- data.frame(na.omit(ordi.mite))

NMDS <- data.frame(x = vare.mds$point[ ,1], y = vare.mds$point[ ,2], Type = group)
NMDS$name <- rownames(NMDS)

ggplot()+
  stat_contour(data = ordi.mite.na, aes(x, y, z = z, color = ..level..), size = 1.5) +#size控制线条粗细
  scale_colour_continuous(high = '#066502', low = '#c4fd70') +
  geom_point(data = NMDS, aes(x, y,fill=cluster), color = 'transparent', pch = 21, size = 5) +#控制点大小
  scale_fill_manual(values = c('#BC3C29FF', '#7876B1FF')) +
  labs(x = 'NMDS1', y = 'NMDS2', color = 'MTCoQ')+theme_classic()+
  annotate("text", label = "de=57.2%, P=0.05", size = 4, x =0, y =0)+
  theme(axis.line=element_line(color='black',size=1))+
  theme(axis.text.x=element_text(size=10,angle=0,color="black"),
        axis.text.y=element_text(size=10,angle=0,color="black"))+
  theme(legend.title = element_text(face = "bold", size = 15))
      
dev.off()