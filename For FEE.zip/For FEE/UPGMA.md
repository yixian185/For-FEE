setwd('/Users/liyixian1990/Desktop/test2')
library(ggtree)
library(ggplot2)

library(treeio)#用这个，popgene那个树用mega打开，另存为nwk，其实就是一些括号
tree<-read.newick('c.nwk')

ggtree(tree) + 
  geom_tippoint(size = 2) +
  geom_tiplab(hjust = -0.1) +
  theme_tree2()

library(ape)
tree <-as.phylo(tree)

group <- read.csv('ctreegroup.csv', row.names = 1,sep=',')
group <- split(row.names(group), group$groups)
library(ggplot2)
p <- ggtree(groupOTU(tree, group), aes(color = group), size = 1) + 
  geom_tippoint(size = 1.5, show.legend = FALSE) +
  geom_tiplab(hjust = -0.1, show.legend = FALSE) + 
  theme_tree2() + 
  xlim_tree(0.1)+
  theme(text=element_text(family='Arial',face='bold',size=17))+
  scale_color_manual(values=c('black',#AD002AFF','#00A087FF'))#这里提供3个颜色，因为有个0分组
p

msp<- read.csv('cms.csv', row.names = 1)

msp$type <- factor(rownames(msp), levels = rev(rownames(msp)))
msp <- reshape2::melt(msp, id = 'type')
msp <- msp[c(1, 3, 2)]
head(msp)

p2 <- p + 
  geom_facet(panel = 'Methylation Relative', data = msp, geom = geom_bar, 
             mapping = aes(x = 100*value, fill = variable), color = 'gray30', 
             orientation = 'y', width = 0.8, stat = 'identity') + 
  scale_fill_manual(values = c('#E64B35FF', '#4DBBD5FF', '#00A087FF', '#8491B4FF')) 
facet_widths(p2, widths = c(1.2, 1.8))

library(export)#输出ppt
graph2ppt(file="cggtree.ppt", append=T, height=6, width=14)

dev.off()
rm(list=ls())