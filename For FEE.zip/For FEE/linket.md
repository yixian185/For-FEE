setwd('/Users/liyixian1990/Desktop/test2')
library(linkET)
library(dplyr)
library(ggplot2)
library(vegan)

gen<-read.csv('cge.csv',header=T,row.names=1)
env<-read.csv('c13.csv',header=T,row.names=1,check.names=F)#这里可以去掉后边输出pdf里的点
h.env<-decostand(env,method='hellinger')

mantel <- mantel_test(gen, h.env,#这个物种距离用的bray，环境用的euclidean
                      spec_select = list(He = 1:1,
                                         I = 1:2,
                                         PPL = 2:3,
                                         eH=3:4,
                                         eI=4:5,
                                         ePPL=5:6)) %>% 
  mutate(rd = cut(r, breaks = c(-Inf, 0.2, 0.4, Inf),
                  labels = c("< 0.2", "0.2 - 0.4", ">= 0.4")),
         pd = cut(p, breaks = c(-Inf, 0.01, 0.05, Inf),
                  labels = c("< 0.01", "0.01 - 0.05", ">= 0.05")))

#mantel1 <- filter(mantel, p < 0.05)去掉灰色线
qcorrplot(correlate(env), type = "upper", diag = FALSE) +
  geom_square() +
  geom_couple(aes(xend=.xend-2,x=.x-1.6,colour = pd, size = rd),data = mantel, curvature = nice_curvature(0.12),
              node.colour = c('#7E6148FF','#ADB6B6FF'),
              node.fill = c('#7E6148FF', '#ADB6B6FF'),
              node.size = c(5, 4),label.size=10,label.colour = 'black',
              label.family = 'Arial')+#这个参数是更改遗传参数那部分的
  scale_fill_gradientn(colours = RColorBrewer::brewer.pal(9, "YlGnBu")) +
  scale_size_manual(values = c(0.5, 1, 2)) +
  geom_diag_label(mapping = aes(x = .x + 2),
                  hjust = 1, angle = 45) +

  theme(text=element_text(family='Arial',face='bold',size=16),
        axis.text.x= element_text(family='Arial',size=16),
        axis.text.y=element_text(family='Arial',size=16))+#强制更改标签的字体和右边的字体 
  scale_color_manual(values = c('#BC3C29FF','#00A087FF','ivory2'))+
  #scale_colour_manual(values = color_pal(3, 0))+
  guides(size = guide_legend(title = "Mantel's r",
                             override.aes = list(colour = "grey35"), 
                             order = 2),
         colour = guide_legend(title = "P-value", 
                               override.aes = list(size = 5), 
                               order = 1),
         fill = guide_colorbar(title = "Pearson's r", order = 3))
dev.off()
rm(list=ls())