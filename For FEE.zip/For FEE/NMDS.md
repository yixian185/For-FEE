setwd('/Users/liyixian1990/Desktop/test2') 
library(vegan)
spe.h<- read.csv("cn4.csv",row.names=1)
#spe.h <- decostand(spe,"hellinger")

spe.h.nmds <- metaMDS(spe.h,distance="euclidean")#用的欧式距离

spe.h.nmds$stress#这个值，0.01，0.02，0.05，之前都可信，0.2以后不可信

stressplot(spe.h.nmds, main = "Shepard")

map<- scores(spe.h.nmds)
write.csv(map,"points.csv")

library(ggplot2)
map<-read.csv("points.csv",header = T)
map<-data.frame(map)
group<-read.csv('cnmds.csv')#这里需要一个group文件

colnames(map)[1]<-'code'

map2 <- merge(group, map,by="code",all=F)

#pich<-c(15,17)

ggplot(data=map2,aes(x=NMDS1,y=NMDS2,
                     color=groups,shape=groups))+
  geom_point(size=5)+
  scale_color_manual(values = c('#3C5488FF', '#DC0000FF'))+
  theme_classic()+
  xlab("NMDS1")+
  ylab("NMDS2")+
  geom_text(aes(x=-0.06,y=0.003,label="stress = 0.00004"),size = 6)+

  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  stat_ellipse(data=map2,level=0.95,
               geom = "polygon",linetype='dashed',size=1,
               aes(fill=groups),
               alpha=0)+
  #scale_shape_manual(values=pich)+
  scale_fill_manual(values = c('#3C5488FF','#DC0000FF'))+
  theme(text = element_text(family = "Arial",size=18))+
  theme(axis.line=element_line(color='black',size=1))+
  theme(axis.text.x=element_text(size=10,angle=0,color="black"),
        axis.text.y=element_text(size=10,angle=0,color="black"))+
  theme(legend.title = element_text(face = "bold", size = 15))